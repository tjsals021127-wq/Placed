import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// 기존 페이지들 임포트
import MainGuest from "./pages/MainGuest";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import MainUser from "./pages/MainUser";
import Contact from "./pages/Contact";
import MyInquiry from "./pages/MyInquiry";
import SearchResults from "./pages/SearchResults";
import InquiryDetail from "./pages/InquiryDetail";
import PlaceDetail from "./pages/PlaceDetail";
import MyReviews from "./pages/MyReviews";

// 1. 마이페이지 컴포넌트 임포트 추가
import MyPage from "./pages/MyPage";

function App() {
  return (
    <Router>
      <Routes>
        {/* 기본 경로 설정 */}
        <Route path="/" element={<MainGuest />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        
        {/* 메인 유저 경로[cite: 1] */}
        <Route path="/main" element={<MainUser />} />
        
        {/* 2. 마이페이지 경로 추가 (MainUser에서 navigate할 주소)[cite: 1] */}
        <Route path="/mypage" element={<MyPage />} />
        
        {/* 기타 서비스 경로[cite: 1] */}
        <Route path="/contact" element={<Contact />} />
        <Route path="/inquiries" element={<MyInquiry />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/inquiry/:id" element={<InquiryDetail />} />
        <Route path="/place/:id" element={<PlaceDetail />} />
        <Route path="/reviews" element={<MyReviews />} />
        <Route path="/place/:id" element={<PlaceDetail />} />
      </Routes>
    </Router>
  );
}

export default App;