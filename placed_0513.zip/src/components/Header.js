import React from "react";
import { useNavigate } from "react-router-dom";
import "./Header.css";

function Header() {
  const navigate = useNavigate();

  return (
    <header className="common-header">
      <div className="header-left" onClick={() => navigate("/main")}>
        {/* public 폴더의 이미지를 불러오는 올바른 방법 */}
        <img 
          src={process.env.PUBLIC_URL + "/placed_logo.png"} 
          alt="PLACED Logo" 
          className="header-logo-img" 
        />
        <h1 className="logo-text">PLACED</h1>
      </div>
      
      <nav className="header-nav">
        <button onClick={() => navigate("/main")}>홈</button>
        <button onClick={() => navigate("/my-reviews")}>내 리뷰</button>
        <button onClick={() => navigate("/contact")}>문의하기</button>
        <button onClick={() => navigate("/mypage")}>마이페이지</button>
        <button className="logout-btn-header" onClick={() => navigate("/")}>
          로그아웃
        </button>
      </nav>
    </header>
  );
}

export default Header;